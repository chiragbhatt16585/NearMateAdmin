-- MySQL dump 10.13  Distrib 8.0.43, for Linux (aarch64)
--
-- Host: localhost    Database: nearmateadmin
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nearmateadmin`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nearmateadmin` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `nearmateadmin`;

--
-- Table structure for table `AuditLog`
--

DROP TABLE IF EXISTS `AuditLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AuditLog` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actorId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AuditLog`
--

LOCK TABLES `AuditLog` WRITE;
/*!40000 ALTER TABLE `AuditLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `AuditLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Booking`
--

DROP TABLE IF EXISTS `Booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Booking` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduledFor` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'requested',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `priceQuoted` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Booking_userId_fkey` (`userId`),
  KEY `Booking_providerId_fkey` (`providerId`),
  KEY `Booking_categoryId_fkey` (`categoryId`),
  CONSTRAINT `Booking_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `ServiceCategory` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Booking_providerId_fkey` FOREIGN KEY (`providerId`) REFERENCES `ServiceProvider` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Booking_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Booking`
--

LOCK TABLES `Booking` WRITE;
/*!40000 ALTER TABLE `Booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `Booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Boost`
--

DROP TABLE IF EXISTS `Boost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Boost` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startAt` datetime(3) NOT NULL,
  `endAt` datetime(3) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `Boost_providerId_fkey` (`providerId`),
  CONSTRAINT `Boost_providerId_fkey` FOREIGN KEY (`providerId`) REFERENCES `ServiceProvider` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Boost`
--

LOCK TABLES `Boost` WRITE;
/*!40000 ALTER TABLE `Boost` DISABLE KEYS */;
/*!40000 ALTER TABLE `Boost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMessage`
--

DROP TABLE IF EXISTS `ChatMessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatMessage` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bookingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senderUserId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `ChatMessage_bookingId_fkey` (`bookingId`),
  CONSTRAINT `ChatMessage_bookingId_fkey` FOREIGN KEY (`bookingId`) REFERENCES `Booking` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMessage`
--

LOCK TABLES `ChatMessage` WRITE;
/*!40000 ALTER TABLE `ChatMessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Partner`
--

DROP TABLE IF EXISTS `Partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Partner` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loginId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `serviceRadiusKm` double NOT NULL DEFAULT '5',
  `isAvailable` tinyint(1) NOT NULL DEFAULT '1',
  `pricingType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priceMin` int DEFAULT NULL,
  `priceMax` int DEFAULT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `planStatus` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `boostActive` tinyint(1) NOT NULL DEFAULT '0',
  `boostStart` datetime(3) DEFAULT NULL,
  `boostEnd` datetime(3) DEFAULT NULL,
  `ratingAvg` double NOT NULL DEFAULT '0',
  `ratingCount` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Partner_phone_key` (`phone`),
  UNIQUE KEY `Partner_email_key` (`email`),
  UNIQUE KEY `Partner_loginId_key` (`loginId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Partner`
--

LOCK TABLES `Partner` WRITE;
/*!40000 ALTER TABLE `Partner` DISABLE KEYS */;
INSERT INTO `Partner` VALUES ('2ce68620-878a-4a11-b532-ecd0bcbc4b26','John Doe','9990001111','john@example.com','JD000001','active','2025-08-20 13:46:00.758','2025-08-20 13:53:19.997',5,1,'hourly',199,499,NULL,'active',0,NULL,NULL,0,0),('ca0f94e0-a817-462a-a5f0-d9ec5be873f9','Chirag Bhatt','9930793707','chiragbhatt16585@gmail.com','CB000001','active','2025-08-20 13:50:48.006','2025-08-20 13:53:05.622',5,1,'hourly',199,399,NULL,'active',0,NULL,NULL,0,0),('e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','Jenis Bhatt','8000063309','jenisbhatt3990@gmail.com','JB000001','active','2025-08-20 13:51:24.464','2025-08-20 13:52:56.282',5,1,'hourly',199,299,NULL,'active',0,NULL,NULL,0,0),('f57d45a0-82a3-4819-a056-484905da9985','Jane Roe','9990002222','jane@example.com','JR000001','active','2025-08-20 13:46:00.772','2025-08-20 13:53:13.204',5,1,'hourly',299,399,NULL,'active',0,NULL,NULL,0,0);
/*!40000 ALTER TABLE `Partner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerBank`
--

DROP TABLE IF EXISTS `PartnerBank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerBank` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `partnerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerBank_partnerId_key` (`partnerId`),
  CONSTRAINT `PartnerBank_partnerId_fkey` FOREIGN KEY (`partnerId`) REFERENCES `Partner` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerBank`
--

LOCK TABLES `PartnerBank` WRITE;
/*!40000 ALTER TABLE `PartnerBank` DISABLE KEYS */;
INSERT INTO `PartnerBank` VALUES ('580c5d3a-2ab2-40df-bd25-2a2c188f52af','2ce68620-878a-4a11-b532-ecd0bcbc4b26','John Doe','1234567890','HDFC0001234','HDFC Bank','2025-08-20 13:46:00.768','2025-08-20 13:46:00.768'),('bedf492d-cb67-4266-82e6-d26a2df3cee0','f57d45a0-82a3-4819-a056-484905da9985','Jane Roe','9876543210','SBIN0005678','State Bank of India','2025-08-20 13:46:00.776','2025-08-20 13:46:00.776');
/*!40000 ALTER TABLE `PartnerBank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerCategory`
--

DROP TABLE IF EXISTS `PartnerCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerCategory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `partnerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serviceCategoryId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PartnerCategory_partnerId_fkey` (`partnerId`),
  KEY `PartnerCategory_serviceCategoryId_fkey` (`serviceCategoryId`),
  CONSTRAINT `PartnerCategory_partnerId_fkey` FOREIGN KEY (`partnerId`) REFERENCES `Partner` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PartnerCategory_serviceCategoryId_fkey` FOREIGN KEY (`serviceCategoryId`) REFERENCES `ServiceCategory` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerCategory`
--

LOCK TABLES `PartnerCategory` WRITE;
/*!40000 ALTER TABLE `PartnerCategory` DISABLE KEYS */;
INSERT INTO `PartnerCategory` VALUES ('0d06a12d-f823-4ea3-9b10-6b996a55aad4','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd220a7-7d03-11f0-9cdd-0ea6e67bf632'),('122cf886-3bbe-479c-bbc0-d9ae86bbbeb1','ca0f94e0-a817-462a-a5f0-d9ec5be873f9','6cd237b2-7d03-11f0-9cdd-0ea6e67bf632'),('328db6d4-1932-44ea-8d45-dc97c44ea33e','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd237b2-7d03-11f0-9cdd-0ea6e67bf632'),('417a3af3-82be-4ced-bec5-edc22aa1906d','f57d45a0-82a3-4819-a056-484905da9985','6cd21805-7d03-11f0-9cdd-0ea6e67bf632'),('5363889e-d3fb-4d62-b11a-cd459f1db18e','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd225a5-7d03-11f0-9cdd-0ea6e67bf632'),('797f1ec4-73cf-45b0-9b4d-1797fbdee535','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd23296-7d03-11f0-9cdd-0ea6e67bf632'),('8b2dcae7-afc4-4bcc-adb7-ad9e2fc3ebdb','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd1ed55-7d03-11f0-9cdd-0ea6e67bf632'),('90242aac-c885-465b-b38d-7f8e8432b614','f57d45a0-82a3-4819-a056-484905da9985','6cd225a5-7d03-11f0-9cdd-0ea6e67bf632'),('953e38a8-63d2-4bac-a192-45c41711c929','ca0f94e0-a817-462a-a5f0-d9ec5be873f9','6cd22d50-7d03-11f0-9cdd-0ea6e67bf632'),('d6f3d88d-1ebb-4931-969f-8086d561956b','e5dcaf40-a390-4d7a-b19b-14eb48c7cdc7','6cd21805-7d03-11f0-9cdd-0ea6e67bf632'),('e9448b6c-5291-4c80-a156-5927bf17747c','2ce68620-878a-4a11-b532-ecd0bcbc4b26','6cd220a7-7d03-11f0-9cdd-0ea6e67bf632');
/*!40000 ALTER TABLE `PartnerCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerKyc`
--

DROP TABLE IF EXISTS `PartnerKyc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerKyc` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `partnerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docUrl` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PartnerKyc_partnerId_fkey` (`partnerId`),
  CONSTRAINT `PartnerKyc_partnerId_fkey` FOREIGN KEY (`partnerId`) REFERENCES `Partner` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerKyc`
--

LOCK TABLES `PartnerKyc` WRITE;
/*!40000 ALTER TABLE `PartnerKyc` DISABLE KEYS */;
INSERT INTO `PartnerKyc` VALUES ('kyc-2ce68620-878a-4a11-b532-ecd0bcbc4b26','2ce68620-878a-4a11-b532-ecd0bcbc4b26','Aadhar Card','XXXXXXXXX',NULL,'verified','2025-08-20 13:46:00.764','2025-08-20 13:46:00.764'),('kyc-f57d45a0-82a3-4819-a056-484905da9985','f57d45a0-82a3-4819-a056-484905da9985','Pan Card','XXXXXXX',NULL,'pending','2025-08-20 13:46:00.774','2025-08-20 13:46:00.774');
/*!40000 ALTER TABLE `PartnerKyc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerRating`
--

DROP TABLE IF EXISTS `PartnerRating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerRating` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `partnerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bookingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerRating_bookingId_key` (`bookingId`),
  KEY `PartnerRating_partnerId_idx` (`partnerId`),
  KEY `PartnerRating_rating_idx` (`rating`),
  CONSTRAINT `PartnerRating_bookingId_fkey` FOREIGN KEY (`bookingId`) REFERENCES `Booking` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PartnerRating_partnerId_fkey` FOREIGN KEY (`partnerId`) REFERENCES `Partner` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerRating`
--

LOCK TABLES `PartnerRating` WRITE;
/*!40000 ALTER TABLE `PartnerRating` DISABLE KEYS */;
/*!40000 ALTER TABLE `PartnerRating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payment` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bookingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `providerRef` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Payment_bookingId_key` (`bookingId`),
  CONSTRAINT `Payment_bookingId_fkey` FOREIGN KEY (`bookingId`) REFERENCES `Booking` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payment`
--

LOCK TABLES `Payment` WRITE;
/*!40000 ALTER TABLE `Payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProviderService`
--

DROP TABLE IF EXISTS `ProviderService`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProviderService` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priceMin` int DEFAULT NULL,
  `priceMax` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ProviderService_providerId_fkey` (`providerId`),
  KEY `ProviderService_categoryId_fkey` (`categoryId`),
  CONSTRAINT `ProviderService_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `ServiceCategory` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ProviderService_providerId_fkey` FOREIGN KEY (`providerId`) REFERENCES `ServiceProvider` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProviderService`
--

LOCK TABLES `ProviderService` WRITE;
/*!40000 ALTER TABLE `ProviderService` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProviderService` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RefreshToken`
--

DROP TABLE IF EXISTS `RefreshToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RefreshToken` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashedToken` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userAgent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revokedAt` datetime(3) DEFAULT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `RefreshToken_userId_fkey` (`userId`),
  CONSTRAINT `RefreshToken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RefreshToken`
--

LOCK TABLES `RefreshToken` WRITE;
/*!40000 ALTER TABLE `RefreshToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `RefreshToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Review`
--

DROP TABLE IF EXISTS `Review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Review` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bookingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Review_bookingId_key` (`bookingId`),
  CONSTRAINT `Review_bookingId_fkey` FOREIGN KEY (`bookingId`) REFERENCES `Booking` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Review`
--

LOCK TABLES `Review` WRITE;
/*!40000 ALTER TABLE `Review` DISABLE KEYS */;
/*!40000 ALTER TABLE `Review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceCategory`
--

DROP TABLE IF EXISTS `ServiceCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceCategory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `popular` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ServiceCategory_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceCategory`
--

LOCK TABLES `ServiceCategory` WRITE;
/*!40000 ALTER TABLE `ServiceCategory` DISABLE KEYS */;
INSERT INTO `ServiceCategory` VALUES ('6cd1ed55-7d03-11f0-9cdd-0ea6e67bf632','plumber','Plumber','🛠️','#E9EEF9',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd21805-7d03-11f0-9cdd-0ea6e67bf632','electrician','Electrician','🔌','#F4ECF7',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd220a7-7d03-11f0-9cdd-0ea6e67bf632','carpenter','Carpenter','🪚','#F0F5F2',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd225a5-7d03-11f0-9cdd-0ea6e67bf632','ac','AC Repair','❄️','#ECF6FB',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd22c03-7d03-11f0-9cdd-0ea6e67bf632','salon','Salon at Home','💇‍♀️','#FEF3F2',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd22d50-7d03-11f0-9cdd-0ea6e67bf632','tutor','Tutor','📚','#F8F1E7',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd22eb6-7d03-11f0-9cdd-0ea6e67bf632','cleaning','Cleaning','🧹','#F3F6EE',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd23016-7d03-11f0-9cdd-0ea6e67bf632','pest','Pest Control','🐜','#FDF6E7',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd23159-7d03-11f0-9cdd-0ea6e67bf632','painting','Painting','🎨','#EAF7F3',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd23296-7d03-11f0-9cdd-0ea6e67bf632','appliances','Appliance Repair','🧺','#F0F0FF',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd233e6-7d03-11f0-9cdd-0ea6e67bf632','moving','Packers & Movers','📦','#FFF0F0',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd2353c-7d03-11f0-9cdd-0ea6e67bf632','gardening','Gardening','🌿','#EAF6EA',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd23668-7d03-11f0-9cdd-0ea6e67bf632','carwash','Car Wash','🚗','#EAF3FB',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255'),('6cd237b2-7d03-11f0-9cdd-0ea6e67bf632','laptop','Laptop Repair','💻','#F2F2F2',0,'2025-08-19 13:50:11.255','2025-08-19 13:50:11.255');
/*!40000 ALTER TABLE `ServiceCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ServiceProvider`
--

DROP TABLE IF EXISTS `ServiceProvider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ServiceProvider` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ratingAvg` double NOT NULL DEFAULT '0',
  `ratingCount` int NOT NULL DEFAULT '0',
  `isVerified` tinyint(1) NOT NULL DEFAULT '0',
  `serviceRadiusKm` double NOT NULL DEFAULT '5',
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ServiceProvider_userId_key` (`userId`),
  CONSTRAINT `ServiceProvider_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ServiceProvider`
--

LOCK TABLES `ServiceProvider` WRITE;
/*!40000 ALTER TABLE `ServiceProvider` DISABLE KEYS */;
/*!40000 ALTER TABLE `ServiceProvider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subscription`
--

DROP TABLE IF EXISTS `Subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Subscription` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `Subscription_providerId_fkey` (`providerId`),
  CONSTRAINT `Subscription_providerId_fkey` FOREIGN KEY (`providerId`) REFERENCES `ServiceProvider` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subscription`
--

LOCK TABLES `Subscription` WRITE;
/*!40000 ALTER TABLE `Subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `Subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashedPassword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('96fe4eae-5b44-424f-b785-fabff59b8e41','admin@nearmate.local','Administrator','$2b$10$vTgxd8ElZJDrgGPjZegpCewFqygEflTJGi9dI3NDJNbK0NadqLDPC','admin','active','2025-08-20 13:46:00.748','2025-08-20 13:46:00.748');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserProfile`
--

DROP TABLE IF EXISTS `UserProfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserProfile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserProfile_userId_key` (`userId`),
  CONSTRAINT `UserProfile_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserProfile`
--

LOCK TABLES `UserProfile` WRITE;
/*!40000 ALTER TABLE `UserProfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserProfile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-20 13:55:34
